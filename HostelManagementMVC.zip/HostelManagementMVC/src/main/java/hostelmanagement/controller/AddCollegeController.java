package hostelmanagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hostelmanagement.dao.HostelManagementDAO;
import hostelmanagement.model.College;

/**
 * Servlet implementation class AddStudentController
 */
@WebServlet("/AddCollegeController")
public class AddCollegeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       HostelManagementDAO dao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCollegeController() {
        super();
        dao = new HostelManagementDAO();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher view = request.getRequestDispatcher("staff/add_college.jsp");
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		College college = new College();
		
		college.setColl_no(request.getParameter("coll_no"));
		college.setColl_name(request.getParameter("coll_name"));
		college.setColl_floor(Integer.parseInt(request.getParameter("coll_floor")));
		college.setColl_room(Integer.parseInt(request.getParameter("coll_room")));
		
		dao.addCollege(college);
		
		request.setAttribute("college", HostelManagementDAO.getAllCollege());
		RequestDispatcher view = request.getRequestDispatcher("staff/list_all_college.jsp");
		view.forward(request, response);
	}

}
