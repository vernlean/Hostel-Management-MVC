package hostelmanagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hostelmanagement.dao.HostelManagementDAO;

/**
 * Servlet implementation class DeleteComplaintStudentController
 */
@WebServlet("/DeleteCollegeApplicationController")
public class DeleteCollegeApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HostelManagementDAO dao;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteCollegeApplicationController() {
		super();
		dao = new HostelManagementDAO();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//SET VARIABLE
		int collap_no = Integer.parseInt(request.getParameter("collap_no"));
		
		//DAO
		dao.deleteCollegeApplication(collap_no);

		//FORWARD TO LIST COLLEGE
		RequestDispatcher view = request.getRequestDispatcher("ListAllCollegeApplicationController");
		view.forward(request, response);
	}
}
