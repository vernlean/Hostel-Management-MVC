package hostelmanagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import hostelmanagement.dao.HostelManagementDAO;

/**
 * Servlet implementation class DeleteComplaintStudentController
 */
@WebServlet("/DeleteComplaintController")
public class DeleteComplaintController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HostelManagementDAO dao;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteComplaintController() {
		super();
		dao = new HostelManagementDAO();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//SET VARIABLE
		int comp_no = Integer.parseInt(request.getParameter("comp_no"));
		
		//DAO
		dao.deleteComplaintByComp_no(comp_no);

		//FORWARD TO COMPLAINT STATUS
		RequestDispatcher view = request.getRequestDispatcher("ListAllComplaintController");
		view.forward(request, response);
	}
}
