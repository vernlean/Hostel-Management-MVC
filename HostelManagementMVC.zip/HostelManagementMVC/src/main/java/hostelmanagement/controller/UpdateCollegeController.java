package hostelmanagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hostelmanagement.dao.HostelManagementDAO;
import hostelmanagement.model.College;

/**
 * Servlet implementation class UpdateStudentController
 */
@WebServlet("/UpdateCollegeController")
public class UpdateCollegeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private HostelManagementDAO dao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCollegeController() {
        super();
        dao = new HostelManagementDAO();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String coll_no = request.getParameter("coll_no");
		request.setAttribute("college", HostelManagementDAO.getCollegeByCollegeNo(coll_no));
		RequestDispatcher view = request.getRequestDispatcher("staff/update_college.jsp");
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		College college = new College();
		
		college.setColl_no(request.getParameter("coll_no"));
		college.setColl_name(request.getParameter("coll_name"));
		college.setColl_floor(Integer.parseInt(request.getParameter("coll_floor")));
		college.setColl_room(Integer.parseInt(request.getParameter("coll_room")));
		college.setColl_status(request.getParameter("coll_status"));
		
		//DAO
		dao.UpdateCollege(college);
		
		//FORWARD TO LIST COLLEGE
		RequestDispatcher view = request.getRequestDispatcher("ListAllCollegeController");
		view.forward(request, response);
	}

}
