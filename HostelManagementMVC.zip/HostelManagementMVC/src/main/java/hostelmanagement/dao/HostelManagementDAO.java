package hostelmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import hostelmanagement.db.ConnectionManager;
import hostelmanagement.model.College;
import hostelmanagement.model.CollegeApplication;
import hostelmanagement.model.Complaint;
import user.model.Student;
import user.model.Staff;

public class HostelManagementDAO {

	static Connection con = null;
	static PreparedStatement ps = null;
	static Statement statement = null;
	static ResultSet rs = null;
	Student student;
	Staff staff;
	String coll_no, coll_name, coll_status, collap_session, collap_status, comp_type, comp_description, comp_status;
	int coll_floor, coll_room, collap_no, stu_no, stf_no, comp_no;
	Date collap_date, comp_date;

	//GET COLLEGE BY STUDENT NUMBER
	public static Object getCollegeApplicationByStu_no(int stu_no) {
		
		CollegeApplication collegeApplication = new CollegeApplication();
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college_application WHERE stu_no = ?");
			ps.setInt(1, stu_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();

			if(rs.next()) {
				collegeApplication.setCollap_no(rs.getInt("collap_no"));
				collegeApplication.setCollap_date(rs.getDate("collap_date"));
				collegeApplication.setCollap_session(rs.getString("collap_session"));
				collegeApplication.setCollap_status(rs.getString("collap_status"));
				collegeApplication.setStu_no(rs.getInt("stu_no"));
				collegeApplication.setStf_no(rs.getInt("stf_no"));
				collegeApplication.setColl_no(rs.getString("coll_no"));
			}
			else {
				return null;
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return collegeApplication;
	}
	//END OF GET COLLEGE BY STUDENT NUMBER

	//GET COLLEGE BY STUDENT NUMBER
	public static Object getCollegeByStu_no(int stu_no) {
		
		College college = new College();
		String coll_no = null;
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college_application WHERE stu_no = ?");
			ps.setInt(1, stu_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();

			if(rs.next()) {
				coll_no=rs.getString("coll_no");
			}

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college WHERE coll_no = ?");
			ps.setString(1, coll_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();

			if(rs.next()) {
				college.setColl_no(rs.getString("coll_no"));
				college.setColl_name(rs.getString("coll_name"));
				college.setColl_floor(Integer.parseInt(rs.getString("coll_floor")));
				college.setColl_room(Integer.parseInt(rs.getString("coll_room")));
			}

			//close connection
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return college;
	}
	//END OF GET COLLEGE BY STUDENT NUMBER

	//GET COLLEGE LIST BY STUDENT NUMBER (AVAILABLE/GENDER)
	public static List<College> getCollegeListByStu_no(int stu_no) {
		
		List<College> colleges = new ArrayList<College>();
		String stu_gender=null;
		try {

			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM student WHERE stu_no = ?");
			ps.setInt(1, stu_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();

			if(rs.next()) {
				stu_gender = rs.getString("stu_gender");
			}

			if(stu_gender.equalsIgnoreCase("Male")) {
				//CREATE STATEMENT
				Statement stmt = con.createStatement();
				String sql = "SELECT * FROM college WHERE (coll_name = 'TUN SRI LANANG A' OR coll_name = 'TUN SRI LANANG B') AND (coll_status = 'Available')";

				//EXECUTE QUERY
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					College c = new College();
					c.setColl_no(rs.getString("coll_no"));
					colleges.add(c);
				}
			}

			else {
				//create statement
				Statement stmt = con.createStatement();
				String sql = "SELECT * FROM college WHERE (coll_name = 'TUN GEMALA A' OR coll_name = 'TUN GEMALA B') AND (coll_status = 'Available')";

				//execute query
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					College c = new College();
					c.setColl_no(rs.getString("coll_no"));
					colleges.add(c);
				}
			}

			//close connection
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return colleges;
	}
	//END OF GET COLLEGE LIST BY STUDENT NUMBER (AVAILABLE/GENDER)

	//ADD COLLEGE APPLICATION
	public void addCollegeApplication(CollegeApplication collap, Student student, College coll) {

		java.util.Date utilDate = collap.getCollap_date();
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		collap_session = collap.getCollap_session();
		collap_status = "Processing";
		stu_no = student.getStu_no();
		stf_no = 101;
		coll_no = coll.getColl_no();
		coll_status = "Unavailable";

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//INSERT NEW COLLEGE APPLICATION
			//CREATE STATEMENT
			ps = con.prepareStatement("INSERT INTO `college_application`(`collap_date`, `collap_session`, `collap_status`, `stu_no`, `stf_no`, `coll_no`) VALUES (?,?,?,?,?,?)");
			ps.setDate(1, sqlDate);
			ps.setString(2, collap_session);
			ps.setString(3, collap_status);
			ps.setInt(4, stu_no);
			ps.setInt(5, stf_no);
			ps.setString(6, coll_no);

			//EXECUTE QUERY
			ps.executeUpdate();

			//SET COLLEGE STATUS TO UNAVAILABLE
			//CREATE STATEMENT
			ps = con.prepareStatement("UPDATE `college` SET `coll_status`=? WHERE `coll_no`=?");
			ps.setString(1, coll_status);
			ps.setString(2, coll_no);

			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//END OF ADD COLLEGE APPLICATION

	//ADD COMPLAINT
	public void addComplaint(Complaint comp, Student student) {
		
		java.util.Date utilDate = comp.getComp_date();
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		comp_type = comp.getComp_type();
		comp_description = comp.getComp_description();
		comp_status = "Processing";
		stu_no = student.getStu_no();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//TO INSERT NEW COMPLAINT
			//CREATE STATEMENT
			ps = con.prepareStatement("INSERT INTO `complaint`(`comp_type`, `comp_date`, `comp_description`, `comp_status`, `stu_no`) VALUES (?,?,?,?,?)");
			ps.setString(1, comp_type);
			ps.setDate(2, sqlDate);
			ps.setString(3,comp_description);
			ps.setString(4,comp_status);
			ps.setInt(5, stu_no);

			//EXECUTE QUERY
			ps.executeUpdate();
			System.out.println("College Application Inserted!");

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//END OF ADD COMPLAINT

	//GET LIST COMPLAINT BY STUDENT NUMBER
	public static List<Complaint> getListComplaintByStu_no(int stu_no) {
		
		List<Complaint> complaints = new ArrayList<Complaint>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM complaint WHERE stu_no = ?");
			ps.setInt(1, stu_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				Complaint comp = new Complaint();
				comp.setComp_no(rs.getInt("comp_no"));
				comp.setComp_type(rs.getString("comp_type"));
				comp.setComp_date(rs.getDate("comp_date"));
				comp.setComp_description(rs.getString("comp_description"));
				comp.setComp_status(rs.getString("comp_status"));

				complaints.add(comp);
			}

			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return complaints;
	}
	//END OF GET LIST COMPLAINT BY STUDENT NUMBER

	//STUDENT COMPLAINT
	//GET COMPLAINT BY COMPLAINT NUMBER 
	public static Object getComplaintByComp_no(int comp_no) {

		Complaint complaint = new Complaint();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();
			System.out.println("Database connected!");

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM complaint WHERE comp_no = ?");
			ps.setInt(1, comp_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();
			if(rs.next()) {
				complaint.setComp_no(rs.getInt("comp_no"));
				complaint.setComp_type(rs.getString("comp_type"));
				complaint.setComp_description(rs.getString("comp_description"));
				complaint.setComp_date(rs.getDate("comp_date"));
				complaint.setComp_status(rs.getString("comp_status"));
				complaint.setStu_no(rs.getInt("stu_no"));
			}

			//CLOSE CONNECTION
			con.close();
			System.out.println("Connection closed!");

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return complaint;
	}
	//END OF COMPLAINT BY COMPLAINT NUMBER 

	//UPDATE COMPLAINT
	public void updateComplaint(Complaint comp, Student student) {

		java.util.Date utilDate = comp.getComp_date();
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		comp_description = comp.getComp_description();
		comp_no = comp.getComp_no();
		stu_no = student.getStu_no();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();
			System.out.println("Database connected!");

			//CREATE STATEMENT
			ps = con.prepareStatement("UPDATE complaint SET comp_date=?, comp_description=? WHERE comp_no=? AND stu_no=?");
			ps.setDate(1, sqlDate);
			ps.setString(2, comp_description);
			ps.setInt(3, comp_no);
			ps.setInt(4, stu_no);
			System.out.println("Date"+sqlDate);
			System.out.println(comp_no);
			System.out.println(comp_description);
			System.out.println(stu_no);
			//EXECUTE QUERY
			ps.executeUpdate();
			System.out.println("Successful Update data!");

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//END OF UPDATE COMPLAINT

	//DELETE COMPLAINT BY COMPLAINT NUMBER
	public void deleteComplaintByComp_no(int comp_no) {
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("DELETE FROM complaint WHERE comp_no = ?");
			ps.setInt(1, comp_no);

			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//END OF DELETE COMPLAINT BY COMPLAINT NUMBER

	//GET ALL COLLEGE
	public static List<College> getAllCollege() {

		List<College> colleges = new ArrayList<College>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college");

			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				College coll = new College();
				coll.setColl_no(rs.getString("coll_no"));
				coll.setColl_name(rs.getString("coll_name"));
				coll.setColl_floor(rs.getInt("coll_floor"));
				coll.setColl_room(rs.getInt("coll_room"));
				coll.setColl_status(rs.getString("coll_status"));
				colleges.add(coll);
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return colleges;
	}
	//END OF GET ALL COLLEGE


	//ADD COLLEGE
	public void addCollege(College college) {
		
		coll_no = college.getColl_no();
		coll_name = college.getColl_name();
		coll_floor = college.getColl_floor();
		coll_room = college.getColl_room();
		coll_status = college.getColl_status();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("INSERT INTO `college`(`coll_no`, `coll_name`, `coll_floor`, `coll_room`, `coll_status`) VALUES (?,?,?,?,?)");
			ps.setString(1, coll_no);
			ps.setString(2, coll_name);
			ps.setInt(3, coll_floor);
			ps.setInt(4, coll_room);
			ps.setString(5, "Available");

			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//END OF ADD COLLEGE

	//DELETE COLLEGE
	public void deleteCollege(String coll_no) {
		
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("DELETE FROM college WHERE coll_no = ?");
			ps.setString(1, coll_no);

			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	//END OF DELETE COLLEGE

	//GET COLLEGE BY COLLEGE NUMBER
	public static Object getCollegeByCollegeNo(String coll_no) {
		College college = new College();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college WHERE coll_no = ?");
			ps.setString(1, coll_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();
			if(rs.next()) {
				
				college.setColl_no(rs.getString("coll_no"));
				college.setColl_name(rs.getString("coll_name"));
				college.setColl_floor(rs.getInt("coll_floor"));
				college.setColl_room(rs.getInt("coll_room"));
				college.setColl_status(rs.getString("coll_status"));
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return college;
	}
	//END OF GET COLLEGE BY COLLEGE NUMBER

	//UPDATE COLLEGE
	public void UpdateCollege(College college) {
		

		coll_no = college.getColl_no();
		coll_name = college.getColl_name();
		coll_floor = college.getColl_floor();
		coll_room = college.getColl_room();
		coll_status = college.getColl_status();
		
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("UPDATE `college` SET `coll_name`=?,`coll_floor`=?,`coll_room`=?,`coll_status`=? WHERE `coll_no`=?");
			ps.setString(1, coll_name);
			ps.setInt(2, coll_floor);
			ps.setInt(3, coll_room);
			ps.setString(4, coll_status);
			ps.setString(5, coll_no);
			
			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//END OF UPDATE COLLEGE

	//GET 
	public static List<Complaint> getAllComplaint() {
		
		List<Complaint> complaints = new ArrayList<Complaint>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM complaint");

			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				Complaint comp = new Complaint();
				comp.setComp_no(rs.getInt("comp_no"));
				comp.setComp_type(rs.getString("comp_type"));
				comp.setComp_date(rs.getDate("comp_date"));
				comp.setComp_description(rs.getString("comp_description"));
				comp.setComp_status(rs.getString("comp_status"));
				comp.setStu_no(rs.getInt("stu_no"));
				complaints.add(comp);
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return complaints;
	}

	//UPDATE COMPLAINT STATUS
	public void updateComplaintStatus(Complaint comp) {

		comp_status = comp.getComp_status();
		comp_no = comp.getComp_no();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("UPDATE complaint SET comp_status=? WHERE comp_no=?");
			ps.setString(1, comp_status);
			ps.setInt(2, comp_no);
			
			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	//END OF UPDATE COMPLAINT STATUS

	//GET ALL COLLEGE APPLICATION
	public static List<CollegeApplication> getAllCollegeApplication() {

		List<CollegeApplication> collegeApplication = new ArrayList<CollegeApplication>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college_application");

			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				CollegeApplication collap = new CollegeApplication();
				collap.setCollap_no(rs.getInt("collap_no"));
				collap.setCollap_date(rs.getDate("collap_date"));
				collap.setCollap_session(rs.getString("collap_session"));
				collap.setCollap_status(rs.getString("collap_status"));
				collap.setStf_no(rs.getInt("stf_no"));
				collap.setStu_no(rs.getInt("stu_no"));
				collap.setColl_no(rs.getString("coll_no"));
				
				collegeApplication.add(collap);
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return collegeApplication;
	}
	//END OF GET ALL COLLEGE APPLICATION

	//DELETE COLLEGE APPLICATION
	public void deleteCollegeApplication(int collap_no) {
		
		try {
			
			//CONNECT TO DB
			con = ConnectionManager.getConnection();
			
			//CREATE STATEMENT
			ps = con.prepareStatement("DELETE FROM college_application WHERE collap_no = ?");
			ps.setInt(1, collap_no);
			
			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	//END OF DELETE COLLEGE APPLICATION

	//GET COLLEGE APPLICATION BY COLLEGE APPLICATION NUMBER
	public static Object getCollegeApplicationByCollegeApplicationNo(String collap_no) {
		
		CollegeApplication collap = new CollegeApplication();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college_application WHERE collap_no = ?");
			ps.setString(1, collap_no);

			//EXECUTE QUERY
			rs = ps.executeQuery();
			if(rs.next()) {
				
				collap.setCollap_no(rs.getInt("collap_no"));
				collap.setCollap_date(rs.getDate("collap_date"));
				collap.setCollap_session(rs.getString("collap_session"));
				collap.setCollap_status(rs.getString("collap_status"));
				collap.setStu_no(rs.getInt("stu_no"));
				collap.setStf_no(rs.getInt("stf_no"));
				collap.setColl_no(rs.getString("coll_no"));
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return collap;
	}
	//END OF GET COLLEGE APPLICATION BY COLLEGE APPLICATION NUMBER

	//UPDATE COLLEGE APPLICATION
	public void UpdateCollegeApplication(CollegeApplication collap) {
		
		collap_no = collap.getCollap_no();
		collap_status = collap.getCollap_status();
		stf_no = collap.getStf_no();
		
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("UPDATE college_application SET collap_status=?, stf_no=? WHERE collap_no=?");
			ps.setString(1, collap_status);
			ps.setInt(2, stf_no);
			ps.setInt(3, collap_no);
			
			//EXECUTE QUERY
			ps.executeUpdate();

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	//END OF UPDATE COLLEGE APPLICATION

	//GET COLLEGE BY SEARCH
	public static List<College> getAllCollegeBySearch(String search) {

		List<College> colleges = new ArrayList<College>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college WHERE CONCAT (coll_no, coll_name, coll_status) LIKE ('%'  ?  '%')");
			ps.setString(1, search);
			System.out.println(search);
			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				College coll = new College();
				coll.setColl_no(rs.getString("coll_no"));
				coll.setColl_name(rs.getString("coll_name"));
				coll.setColl_floor(rs.getInt("coll_floor"));
				coll.setColl_room(rs.getInt("coll_room"));
				coll.setColl_status(rs.getString("coll_status"));
				colleges.add(coll);
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return colleges;
	}
	//END OF GET COLLEGE BY SEARCH

	//GET COMPLAINT BY SEARCH
	public static List<Complaint> getAllComplaintBySearch(String search) {

		List<Complaint> complaints = new ArrayList<Complaint>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM complaint WHERE CONCAT (comp_no, comp_type, comp_status, stu_no) LIKE ('%'  ?  '%')");
			ps.setString(1, search);
			System.out.println(search);
			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				Complaint comp = new Complaint();
				comp.setComp_no(rs.getInt("comp_no"));
				comp.setComp_type(rs.getString("comp_type"));
				comp.setComp_date(rs.getDate("comp_date"));
				comp.setComp_description(rs.getString("comp_description"));
				comp.setComp_status(rs.getString("comp_status"));
				comp.setStu_no(rs.getInt("stu_no"));

				complaints.add(comp);
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return complaints;
	}
	//END OF GET COMPLAINT BY SEARCH

	//GET COLLEGE APPLICAITON BY SEARCH
	public static List<CollegeApplication> getAllCollegeApplicationBySearch(String search) {
		
		List<CollegeApplication> collegeApplications = new ArrayList<CollegeApplication>();

		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT * FROM college_application WHERE CONCAT (collap_no, collap_session, collap_status, stu_no, coll_no) LIKE ('%'  ?  '%')");
			ps.setString(1, search);
			System.out.println(search);
			//EXECUTE QUERY
			rs = ps.executeQuery();

			while(rs.next()) {
				CollegeApplication collap = new CollegeApplication();
				collap.setCollap_no(rs.getInt("collap_no"));
				collap.setCollap_date(rs.getDate("collap_date"));
				collap.setCollap_session(rs.getString("collap_session"));
				collap.setCollap_status(rs.getString("collap_status"));
				collap.setStu_no(rs.getInt("stu_no"));
				collap.setColl_no(rs.getString("coll_no"));
				collegeApplications.add(collap);
			}

			//CLOSE CONNECTION
			con.close();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return collegeApplications;
	}
	//END OF GET COLLEGE APPLICAITON BY SEARCH

}
