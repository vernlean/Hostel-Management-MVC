package hostelmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import hostelmanagement.db.ConnectionManager;
import hostelmanagement.model.Report;

public class ReportDAO {
	static Connection con = null;
	static PreparedStatement ps = null;
	static Statement statement = null;
	static ResultSet rs = null;
	
	//GET REPORT
	public static Object getAllReport() {
		
		Report report = new Report();
		
		try {
			//CONNECT TO DB
			con = ConnectionManager.getConnection();

			//COUNT STUDENT
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_student FROM student");

			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_student(rs.getInt("count_student"));
			}
			
			//COUNT MALE
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_male FROM student WHERE stu_gender=?");
			ps.setString(1, "Male");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_male(rs.getInt("count_male"));
			}
			
			//COUNT FEMALE
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_female FROM student WHERE stu_gender=?");
			ps.setString(1, "female");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_female(rs.getInt("count_female"));
			}
			
			//COUNT COLLEGE
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_college FROM college");

			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_college(rs.getInt("count_college"));
			}
			
			//COUNT COLLEGE AVAILABLE
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_coll_available FROM college WHERE coll_status =?");
			ps.setString(1, "Available");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_coll_available(rs.getInt("count_coll_available"));
			}
			
			//COUNT COLLEGE UNAVAILABLE
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_coll_unavailable FROM college WHERE coll_status =?");
			ps.setString(1, "Unavailable");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_coll_unavailable(rs.getInt("count_coll_unavailable"));
			}
			
			//COUNT COLLEGE TUN SRI LANANG
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_TSL FROM college WHERE coll_name LIKE (  ?  '%')");
			ps.setString(1, "Tun Sri Lanang");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_TSL(rs.getInt("count_TSL"));
			}
			
			//COUNT COLLEGE TUN GEMALA
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_TG FROM college WHERE coll_name LIKE (  ?  '%')");
			ps.setString(1, "Tun Gemala");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_TG(rs.getInt("count_TG"));
			}
			
			//COUNT COLLEGE APPLICATION
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_application FROM college_application");

			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_application(rs.getInt("count_application"));
			}
			
			//COUNT COLLEGE APPLICATION PROCESSING
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_app_processing FROM college_application WHERE collap_status=?");
			ps.setString(1, "Processing");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_app_processing(rs.getInt("count_app_processing"));
			}
			
			//COUNT COLLEGE APPLICATION APPROVED
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_app_approved FROM college_application WHERE collap_status=?");
			ps.setString(1, "Approved");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_app_approved(rs.getInt("count_app_approved"));
			}
			
			//COUNT COLLEGE APPLICATION FAILED
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_app_failed FROM college_application WHERE collap_status=?");
			ps.setString(1, "Failed");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_app_failed(rs.getInt("count_app_failed"));
			}
			
			//COUNT COMPLAINT
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_complaint FROM complaint");

			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_complaint(rs.getInt("count_complaint"));
			}
			
			//COUNT COMPLAINT PROCESSING
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_comp_processing FROM complaint WHERE comp_status=?");
			ps.setString(1,"Processing");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_comp_processing(rs.getInt("count_comp_processing"));
			}
			
			//COUNT COMPLAINT REVIEWED
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_comp_reviewed FROM complaint WHERE comp_status=?");
			ps.setString(1,"Reviewed");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_comp_reviewed(rs.getInt("count_comp_reviewed"));
			}
			
			//COUNT COMPLAINT FIXED
			//CREATE STATEMENT
			ps = con.prepareStatement("SELECT COUNT(*) AS count_comp_fixed FROM complaint WHERE comp_status=?");
			ps.setString(1,"Fixed");
			
			//execute query
			rs = ps.executeQuery();
			
			if(rs.next()) {
				report.setCount_comp_fixed(rs.getInt("count_comp_fixed"));
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return report;
	}
	//END OF GET REPORT
	
	
}
