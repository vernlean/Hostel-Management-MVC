package hostelmanagement.model;

public class College {
	
	private String coll_no;
	private String coll_name;
	private int coll_floor;
	private int coll_room;
	private String coll_status;
	
	public String getColl_no() {
		return coll_no;
	}
	public void setColl_no(String coll_no) {
		this.coll_no = coll_no;
	}
	public String getColl_name() {
		return coll_name;
	}
	public void setColl_name(String coll_name) {
		this.coll_name = coll_name;
	}
	public int getColl_floor() {
		return coll_floor;
	}
	public void setColl_floor(int coll_floor) {
		this.coll_floor = coll_floor;
	}
	public int getColl_room() {
		return coll_room;
	}
	public void setColl_room(int coll_room) {
		this.coll_room = coll_room;
	}
	public String getColl_status() {
		return coll_status;
	}
	public void setColl_status(String coll_status) {
		this.coll_status = coll_status;
	}
	
	
}
