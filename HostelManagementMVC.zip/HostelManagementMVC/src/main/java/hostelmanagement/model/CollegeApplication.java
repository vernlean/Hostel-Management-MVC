package hostelmanagement.model;

import java.util.Date;

public class CollegeApplication {
	
	private int collap_no;
	private Date collap_date;
	private String collap_session;
	private String collap_status;
	private int stu_no;
	private  int stf_no;
	private String coll_no;
	
	public int getCollap_no() {
		return collap_no;
	}
	public void setCollap_no(int collap_no) {
		this.collap_no = collap_no;
	}
	public Date getCollap_date() {
		return collap_date;
	}
	public void setCollap_date(Date collap_date) {
		this.collap_date = collap_date;
	}
	public String getCollap_session() {
		return collap_session;
	}
	public void setCollap_session(String collap_session) {
		this.collap_session = collap_session;
	}
	public String getCollap_status() {
		return collap_status;
	}
	public void setCollap_status(String collap_status) {
		this.collap_status = collap_status;
	}
	public int getStu_no() {
		return stu_no;
	}
	public void setStu_no(int stu_no) {
		this.stu_no = stu_no;
	}
	public int getStf_no() {
		return stf_no;
	}
	public void setStf_no(int stf_no) {
		this.stf_no = stf_no;
	}
	public String getColl_no() {
		return coll_no;
	}
	public void setColl_no(String coll_no) {
		this.coll_no = coll_no;
	}
	
}
