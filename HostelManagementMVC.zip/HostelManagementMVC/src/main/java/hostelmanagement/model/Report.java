package hostelmanagement.model;

public class Report {
	
	int count_student;
	int count_male;
	int count_female;
	
	int count_college;
	int count_coll_available;
	int count_coll_unavailable;
	int count_TSL;
	int count_TG;
	
	int count_application;
	int count_app_processing;
	int count_app_approved;
	int count_app_failed;
	
	int count_complaint;
	int count_comp_processing;
	int count_comp_reviewed;
	int count_comp_fixed;
	
	public int getCount_student() {
		return count_student;
	}
	public void setCount_student(int count_student) {
		this.count_student = count_student;
	}
	public int getCount_male() {
		return count_male;
	}
	public void setCount_male(int count_male) {
		this.count_male = count_male;
	}
	public int getCount_female() {
		return count_female;
	}
	public void setCount_female(int count_female) {
		this.count_female = count_female;
	}
	public int getCount_college() {
		return count_college;
	}
	public void setCount_college(int count_college) {
		this.count_college = count_college;
	}
	public int getCount_coll_available() {
		return count_coll_available;
	}
	public void setCount_coll_available(int count_coll_available) {
		this.count_coll_available = count_coll_available;
	}
	public int getCount_coll_unavailable() {
		return count_coll_unavailable;
	}
	public void setCount_coll_unavailable(int count_coll_unavailable) {
		this.count_coll_unavailable = count_coll_unavailable;
	}
	public int getCount_TSL() {
		return count_TSL;
	}
	public void setCount_TSL(int count_TSL) {
		this.count_TSL = count_TSL;
	}
	public int getCount_TG() {
		return count_TG;
	}
	public void setCount_TG(int count_TG) {
		this.count_TG = count_TG;
	}
	public int getCount_application() {
		return count_application;
	}
	public void setCount_application(int count_application) {
		this.count_application = count_application;
	}
	public int getCount_app_processing() {
		return count_app_processing;
	}
	public void setCount_app_processing(int count_app_processing) {
		this.count_app_processing = count_app_processing;
	}
	public int getCount_app_approved() {
		return count_app_approved;
	}
	public void setCount_app_approved(int count_app_approved) {
		this.count_app_approved = count_app_approved;
	}
	public int getCount_app_failed() {
		return count_app_failed;
	}
	public void setCount_app_failed(int count_app_failed) {
		this.count_app_failed = count_app_failed;
	}
	public int getCount_complaint() {
		return count_complaint;
	}
	public void setCount_complaint(int count_complaint) {
		this.count_complaint = count_complaint;
	}
	public int getCount_comp_processing() {
		return count_comp_processing;
	}
	public void setCount_comp_processing(int count_comp_processing) {
		this.count_comp_processing = count_comp_processing;
	}
	public int getCount_comp_reviewed() {
		return count_comp_reviewed;
	}
	public void setCount_comp_reviewed(int count_comp_reviewed) {
		this.count_comp_reviewed = count_comp_reviewed;
	}
	public int getCount_comp_fixed() {
		return count_comp_fixed;
	}
	public void setCount_comp_fixed(int count_comp_fixed) {
		this.count_comp_fixed = count_comp_fixed;
	}
	
	
}
